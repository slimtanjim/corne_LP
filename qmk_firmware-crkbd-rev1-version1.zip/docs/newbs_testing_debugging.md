# Testing and Debugging

## Testing

[Moved here](faq_misc#testing)

## Debugging {#debugging}

[Moved here](faq_debug#debugging)
